# Object_detection > lesian_v4
https://universe.roboflow.com/objectdetection-sdaq1/object_detection-e1rvw

Provided by a Roboflow user
License: CC BY 4.0

